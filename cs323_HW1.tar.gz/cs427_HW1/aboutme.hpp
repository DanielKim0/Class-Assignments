// Author: Daniel Kim
// netid: dk763
// Course Number: CS 427
// Assignment Number: 1

void run();
int get_current_year();
int input_year();
