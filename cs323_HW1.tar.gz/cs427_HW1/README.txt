Files:
aboutme.cpp, aboutme.hpp, aboutme.o: Files that I wrote/generated to complete the homework.
tools.cpp, tools.hpp, tools.o: Tools files provided to me.
README.txt: This file, that describes the files in this directory and how to run the code.
aboutme.out: File that contains sample inputs and outputs.
Makefile: File that makes the executable.
aboutme: The executable file that you run.

How to run the code:
First, run make in the submission directory.
Then, run the executable file named aboutme.
